#!/bin/bash
# post-install.sh — ScyllaDB post-install: TLS certs, scylla.yaml, data dirs, systemd overrides.
# Derived from setup-scylla-tls.sh. Idempotent: safe to run multiple times.
set -euo pipefail

STATE_DIR="${STATE_DIR:-/var/lib/globular}"
NODE_IP="${NODE_IP:-}"

echo "[scylladb/post-install] Starting ScyllaDB post-install..."

# ── 1. Detect local IP ───────────────────────────────────────────────────
if [[ -z "${NODE_IP}" ]]; then
    NODE_IP=$(ip route get 8.8.8.8 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1); exit}')
fi
if [[ -z "${NODE_IP}" ]]; then
    NODE_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
fi
if [[ -z "${NODE_IP}" ]]; then
    echo "[scylladb/post-install] ERROR: Cannot detect local IP" >&2
    exit 1
fi
echo "[scylladb/post-install] Node IP: ${NODE_IP}"

# ── 2. Copy TLS certificates ─────────────────────────────────────────────
SCYLLA_TLS_DIR="/etc/scylla/tls"
PKI_CERT_DIR="${STATE_DIR}/pki/issued/services"
PKI_DIR="${STATE_DIR}/pki"

mkdir -p "${SCYLLA_TLS_DIR}"

if [[ -f "${PKI_CERT_DIR}/service.crt" ]]; then
    cp "${PKI_CERT_DIR}/service.crt" "${SCYLLA_TLS_DIR}/server.crt"
    cp "${PKI_CERT_DIR}/service.key" "${SCYLLA_TLS_DIR}/server.key"
    cp "${PKI_DIR}/ca.pem" "${SCYLLA_TLS_DIR}/ca.crt"

    chown -R scylla:scylla "${SCYLLA_TLS_DIR}" 2>/dev/null || true
    chmod 755 "${SCYLLA_TLS_DIR}"
    chmod 644 "${SCYLLA_TLS_DIR}/server.crt" "${SCYLLA_TLS_DIR}/ca.crt"
    chmod 400 "${SCYLLA_TLS_DIR}/server.key"
    echo "[scylladb/post-install] ✓ TLS certificates copied"
else
    echo "[scylladb/post-install] ⚠ PKI certs not found — TLS setup skipped"
    echo "[scylladb/post-install]   Run setup-tls.sh first"
fi

# ── 3. Write scylla.yaml ─────────────────────────────────────────────────
SCYLLA_YAML="/etc/scylla/scylla.yaml"

if [[ -f "${SCYLLA_YAML}" ]]; then
    cp "${SCYLLA_YAML}" "${SCYLLA_YAML}.backup-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
fi

cat > "${SCYLLA_YAML}" <<EOF
seed_provider:
  - class_name: org.apache.cassandra.locator.SimpleSeedProvider
    parameters:
      - seeds: "${NODE_IP}"

client_encryption_options:
  enabled: true
  certificate: /etc/scylla/tls/server.crt
  keyfile: /etc/scylla/tls/server.key
  truststore: /etc/scylla/tls/ca.crt
  require_client_auth: false

native_transport_port_ssl: 9142
listen_address: ${NODE_IP}
rpc_address: ${NODE_IP}
native_transport_port: 9042
broadcast_address: ${NODE_IP}
broadcast_rpc_address: ${NODE_IP}
endpoint_snitch: SimpleSnitch
developer_mode: true

data_file_directories:
  - /var/lib/scylla/data

commitlog_directory: /var/lib/scylla/commitlog
commitlog_sync: batch
commitlog_sync_batch_window_in_ms: 2
commitlog_sync_period_in_ms: 10000
auto_adjust_flush_quota: true
api_port: 56093
api_address: ${NODE_IP}
EOF

echo "[scylladb/post-install] ✓ scylla.yaml written"

# ── 4. Data directories ──────────────────────────────────────────────────
for dir in /var/lib/scylla /var/lib/scylla/data /var/lib/scylla/commitlog; do
    mkdir -p "$dir"
done
chown -R scylla:scylla /var/lib/scylla 2>/dev/null || true

# Ensure /var/lib/scylla/conf → /etc/scylla symlink
SCYLLA_DATA_CONF="/var/lib/scylla/conf"
if [[ -L "${SCYLLA_DATA_CONF}" ]]; then
    : # symlink exists
elif [[ -d "${SCYLLA_DATA_CONF}" ]]; then
    ln -sf "${SCYLLA_YAML}" "${SCYLLA_DATA_CONF}/scylla.yaml"
else
    ln -sfn /etc/scylla "${SCYLLA_DATA_CONF}"
fi
echo "[scylladb/post-install] ✓ Data directories ready"

# ── 5. Environment / sysconfig ────────────────────────────────────────────
SCYLLA_ENV_FILE="/etc/sysconfig/scylla-server"
if [[ ! -f "${SCYLLA_ENV_FILE}" ]]; then
    mkdir -p /etc/sysconfig
    cat > "${SCYLLA_ENV_FILE}" <<'ENVEOF'
SCYLLA_ARGS="--log-to-syslog 1 --log-to-stdout 0 --default-log-level info --network-stack posix"
SCYLLA_HOME="/var/lib/scylla"
ENVEOF
fi

# Ensure scylla.d conf files exist
if [[ -d /etc/scylla.d ]] && ! ls /etc/scylla.d/*.conf &>/dev/null; then
    echo "DEV_MODE=--developer-mode=1" > /etc/scylla.d/dev-mode.conf
    echo "# memory.conf" > /etc/scylla.d/memory.conf
    echo "# io.conf" > /etc/scylla.d/io.conf
    echo "# cpuset.conf" > /etc/scylla.d/cpuset.conf
fi

# ── 6. Systemd overrides ─────────────────────────────────────────────────
SCYLLA_OVERRIDE_DIR="/etc/systemd/system/scylla-server.service.d"
mkdir -p "${SCYLLA_OVERRIDE_DIR}"

if [[ ! -f "${SCYLLA_OVERRIDE_DIR}/sysconfdir.conf" ]]; then
    cat > "${SCYLLA_OVERRIDE_DIR}/sysconfdir.conf" <<'SYSEOF'
[Service]
EnvironmentFile=
EnvironmentFile=-/etc/sysconfig/scylla-server
EnvironmentFile=-/etc/scylla.d/*.conf
SYSEOF
fi

if [[ ! -f "${SCYLLA_OVERRIDE_DIR}/dependencies.conf" ]]; then
    cat > "${SCYLLA_OVERRIDE_DIR}/dependencies.conf" <<'DEPEOF'
[Unit]
After=network-online.target
Wants=network-online.target
DEPEOF
fi

systemctl daemon-reload
echo "[scylladb/post-install] ✓ Systemd overrides installed"

# ── 7. Start/restart ScyllaDB ────────────────────────────────────────────
if systemctl is-active --quiet scylla-server.service; then
    echo "[scylladb/post-install] Restarting ScyllaDB..."
    systemctl restart scylla-server.service
else
    echo "[scylladb/post-install] Starting ScyllaDB..."
    systemctl start scylla-server.service || true
fi
systemctl enable scylla-server.service 2>/dev/null || true

# Wait for CQL port
echo "[scylladb/post-install] Waiting for port 9042..."
for i in $(seq 1 90); do
    if ss -tlnp 2>/dev/null | grep -q ":9042 "; then
        echo "[scylladb/post-install] ✓ ScyllaDB ready (took ${i}s)"
        break
    fi
    sleep 1
done

echo "[scylladb/post-install] ✓ ScyllaDB post-install complete"
